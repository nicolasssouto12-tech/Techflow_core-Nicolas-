Etapa 04 – Parecer Técnico
1. Diferenças entre CLI, Web e Desktop

A CLI é uma interface que funciona por meio de textos e comandos digitados no terminal. A Web funciona pelo navegador, utilizando servidores e interfaces dinâmicas. Já o Desktop é um programa instalado diretamente no computador, com uma interface visual.

2. Vantagens e desvantagens

A CLI apresenta baixo consumo de recursos, alta velocidade e facilidade de automação, mas exige maior conhecimento de comandos. A Web permite acesso remoto, atualizações centralizadas e não exige instalação local, mas pode depender da internet e do desempenho do navegador. O Desktop permite processamento local, acesso ao hardware e funcionamento sem internet, mas pode apresentar dificuldades de atualização e compatibilidade entre sistemas operacionais.

3. Justificativa da escolha do Python CLI

Escolhemos Python CLI para o TechFlow Core por ser uma solução eficiente, rápida e econômica. O Python possui sintaxe simples, permite automação de tarefas, consome pouca memória e oferece diversas bibliotecas. Além disso, facilita a portabilidade e futuras integrações do sistema.