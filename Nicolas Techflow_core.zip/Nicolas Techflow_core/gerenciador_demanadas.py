
demandas = []


def cadastrar_demanda():
    print("\nCADASTRO DE DEMANDA")

    id_demanda = input("Digite o ID: ")
    titulo = input("Digite o título: ")
    solicitante = input("Digite o solicitante: ")
    prioridade = input("Digite a prioridade: ")
    cep = input("Digite o CEP: ")
    cidade = input("Digite a cidade: ")
    status = input("Digite o status: ")

    if id_demanda == "" or titulo == "" or solicitante == "" or prioridade == "" or cep == "" or cidade == "" or status == "":
        print("Erro: todos os campos devem ser preenchidos!")
        return

    for demanda in demandas:
        if demanda["id"] == id_demanda:
            print("Erro: já existe uma demanda com esse ID!")
            return

    nova_demanda = {
        "id": id_demanda,
        "titulo": titulo,
        "solicitante": solicitante,
        "prioridade": prioridade,
        "cep": cep,
        "cidade": cidade,
        "status": status
    }

    demandas.append(nova_demanda)
    print("Demanda cadastrada com sucesso!")


def listar_demandas():
    print("\nLISTA DE DEMANDAS")

    if len(demandas) == 0:
        print("Nenhuma demanda cadastrada.")
        return

    for demanda in demandas:
        print("--------------------")
        print("ID:", demanda["id"])
        print("Título:", demanda["titulo"])
        print("Solicitante:", demanda["solicitante"])
        print("Prioridade:", demanda["prioridade"])
        print("CEP:", demanda["cep"])
        print("Cidade:", demanda["cidade"])
        print("Status:", demanda["status"])


def buscar_demanda():
    print("\nBUSCAR DEMANDA")

    id_busca = input("Digite o ID da demanda: ")

    for demanda in demandas:
        if demanda["id"] == id_busca:
            print("Demanda encontrada!")
            print(demanda)
            return

    print("Demanda não encontrada!")


def atualizar_status():
    print("\nATUALIZAR STATUS")

    id_busca = input("Digite o ID da demanda: ")

    for demanda in demandas:
        if demanda["id"] == id_busca:
            novo_status = input("Digite o novo status: ")

            if novo_status == "":
                print("Erro: o status não pode ficar vazio!")
                return

            demanda["status"] = novo_status

            print("Status atualizado com sucesso!")
            return

    print("Demanda não encontrada!")


def excluir_demanda():
    print("\nEXCLUIR DEMANDA")

    id_busca = input("Digite o ID da demanda que deseja excluir: ")

    for demanda in demandas:
        if demanda["id"] == id_busca:
            demandas.remove(demanda)
            print("Demanda excluída com sucesso!")
            return

    print("Demanda não encontrada!")


def menu():
    while True:
        print("\n===== TECHFLOW CORE =====")
        print("1 - Cadastrar demanda")
        print("2 - Listar demandas")
        print("3 - Buscar demandas")
        print("4 - Atualizar status")
        print("5 - Excluir demanda")
        print("0 - Sair")

        opcao = input("Escolha uma opção: ")

        if opcao == "1":
            cadastrar_demanda()

        elif opcao == "2":
            listar_demandas()

        elif opcao == "3":
            buscar_demanda()

        elif opcao == "4":
            atualizar_status()

        elif opcao == "5":
            excluir_demanda()

        elif opcao == "0":
            print("Encerrando o TechFlow Core...")
            break

        else:
            print("Opção inválida! Tente novamente.")


menu()
