# TechFlow Core

## Sobre o projeto
O TechFlow Core é um sistema desenvolvido em Python para gerenciar demandas de uma empresa por meio de um menu no terminal.

## Funcionalidades
- Cadastrar demandas.
- Listar demandas.
- Buscar demandas pelo ID.
- Atualizar o status.
- Excluir demandas.
- Filtrar demandas por prioridade.
- Consultar CEP.
- Registrar valores em reais ou dólares.

## Tecnologias utilizadas
- Python
- Biblioteca padrão do Python
- APIs ViaCEP e AwesomeAPI

## Como executar
1. Abra a pasta do projeto no VS Code.
2. Abra o terminal.
3. Execute:

`py gerenciador_demanadas.py`

## Observações
As consultas externas dependem de conexão com a internet e podem ser bloqueadas pelo ambiente do SENAI.

## Objetivo
Desenvolver um sistema organizado, funcional e de fácil manutenção, aplicando boas práticas de programação.